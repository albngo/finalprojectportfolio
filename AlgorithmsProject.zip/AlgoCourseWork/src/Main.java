import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
    // Q1
    // Time: O(n^2) | Space: O(1)
    private static int[] hybridSort(int[] array) {
        // We create a boolean to check if there are any swaps made. If there are no swaps made, it means that the array is already sorted.
        int n = array.length;
        boolean swapsMade = true;
        while (swapsMade) {
            swapsMade = false;
            // Bubble Sort part
            for (int i = 0; i < n - 1; i++) {
                if (array[i] > array[i + 1]) {
                    // Swap elements
                    swap(array, i, i + 1);
                    swapsMade = true;
                    // Selection Sort part
                    // Find the minimum value in the array during the bubble sort inner loop
                    int minValueIndex = i + 1;
                    for (int j = i + 2; j < n; j++) {
                        if (array[j] < array[minValueIndex]) {
                            minValueIndex = j;
                        }
                    }
                    // Swap the minimum value with the number in the position where it should be
                    swap(array, i + 1, minValueIndex);
                }
            }
        }
        return array;
    }
    // Q2
    // Time: O(m * n) | Space: O(1)
    private static int[] organiserSort(int[] array, int[] order) {
        // We assume that the order array contains all the elements in the array
        // We also assume that the order array does not contain any duplicates
        // We create some variables to store the length of the array and the order array to make the code more readable.
        int n = array.length;
        int m = order.length;
        int counter = 0;
        // We loop through the order array and find the position of each element in the array
        for (int i = 0; i < m; i++) {
            int currentOrder = order[i];
            for (int j = 0; j < n; j++) {
                if (array[j] == currentOrder) {
                    // Swap elements to move the current order to the correct position
                    swap(array, counter++, j);
                }
            }
        }
        return array;
    }

    // Q3
    // Time: O(n + k), where n is the number of elements and k is the range of elements
    // Space: O(k)
    private static int[] modifiedCountingSort(int[] array) {
        // We find the minimum and maximum values in the array
        // We assume that the array contains at least one element
        int min = Arrays.stream(array).min().getAsInt();
        int max = Arrays.stream(array).max().getAsInt();
        // Calculate the range of elements
        int range = max - min + 1;
        // Create count array
        int[] count = new int[range];
        // Populate count array
        for (int i = 0; i < array.length; i++) {
            count[array[i] - min]++;
        }
        // Sort array
        // We create an arrayIndex variable to keep track of the index of the array
        // We loop through the count array and populate the original array with the sorted elements
        int arrayIndex = 0;
        for (int i = 0; i < range; i++) {
            while (count[i] > 0) {
                array[arrayIndex] = i + min;
                count[i]--;
                arrayIndex++;
            }
        }
        return array;
    }

    // Q4
    // Time: O(n + k) | Space: O(n + k)
    private static int[] mountainSort(int[] array) {
        int n = array.length;
        // Copy the original array
        // We need to copy the original array because we need to use the original array to store the sorted elements
        int[] copyArray = Arrays.copyOf(array, n);
        // Sort the copy array
        // We use the modified counting sort algorithm to sort the copy array
        modifiedCountingSort(copyArray);
        // Split the sorted copy array into two halves
        // We reverse the right half and merge the two halves back into the original array
        int[] leftHalf = Arrays.copyOfRange(copyArray, 0, n / 2);
        int[] rightHalf = Arrays.copyOfRange(copyArray, n / 2, n);
        // Reverse the right half
        // We loop through the right half and swap the elements
        // We only need to loop through half of the right half because we are swapping two elements at a time
        for (int i = 0; i < n / 4; i++) {
            int temp = rightHalf[i];
            rightHalf[i] = rightHalf[n / 2 - 1 - i];
            rightHalf[n / 2 - 1 - i] = temp;
        }
        // Merge the two halves back into the original array
        System.arraycopy(leftHalf, 0, array, 0, n / 2);
        System.arraycopy(rightHalf, 0, array, n / 2, n / 2);
        return array;
    }

    private static void swap(int[] array, int i, int j) {//Do not edit
        int temp = array[j];
        array[j] = array[i];
        array[i] = temp;
    }

    public static void main(String[] args) {
        //You can edit here for your own testing
        System.out.println("Question 1 test cases:");
        // Test Case 1
        int[] array1 = {9, 8, 7, 6};
        hybridSort(array1);
        System.out.println(Arrays.toString(array1)); // Expected: [6, 7, 8, 9]
        // Test Case 2
        int[] array2 = {5, 3, 10, 2, 8};
        hybridSort(array2);
        System.out.println(Arrays.toString(array2)); // Expected: [2, 3, 5, 8, 10]
        // Test Case 3
        int[] array3 = {1, 2, 3, 4, 5};
        hybridSort(array3);
        System.out.println(Arrays.toString(array3)); // Expected: [1, 2, 3, 4, 5]
        // Test Case 4
        int[] array4 = {5, 4, 3, 2, 1};
        hybridSort(array4);
        System.out.println(Arrays.toString(array4)); // Expected: [1, 2, 3, 4, 5]
        // Test Case 5
        int[] array5 = {10, 5, 8, 2, 7};
        hybridSort(array5);
        System.out.println(Arrays.toString(array5)); // Expected: [2, 5, 7, 8, 10]
        // Test Case 5
        int[] array6 = {10, 8, 8, 2, 7};
        hybridSort(array6);
        System.out.println(Arrays.toString(array6)); // Expected: [2, 7, 8, 8, 10]

        System.out.println("Question 2 Test Cases:");
        /// Test Case 1
        int[] arr1 = {0, 2, -1, 0, 2, -1, -1};
        int[] order1 = {0, 2, -1};
        organiserSort(arr1, order1);
        System.out.println(Arrays.toString(arr1)); // Expected: [0, 0, 2, 2, -1, -1, -1]

        // Test Case 2
        int[] arr2 = {5, 3, 10, 2, 8};
        int[] order2 = {3, 5, 8, 10};
        organiserSort(arr2, order2);
        System.out.println(Arrays.toString(arr2)); // Expected: [3, 5, 10, 8, 2]

        // Test Case 3
        int[] arr3 = {1, 2, 3, 4, 5};
        int[] order3 = {5, 4, 3, 2, 1};
        organiserSort(arr3, order3);
        System.out.println(Arrays.toString(arr3)); // Expected: [5, 4, 3, 2, 1]

        // Test Case 4
        int[] arr4 = {10, 5, 8, 2, 7};
        int[] order4 = {5, 2, 10};
        organiserSort(arr4, order4);
        System.out.println(Arrays.toString(arr4)); // Expected: [5, 2, 10, 8, 7]

        // Test Case 5
        int[] arr5 = {1, 2, 3, 4, 5};
        int[] order5 = {6, 7, 8};
        organiserSort(arr5, order5);
        System.out.println(Arrays.toString(arr5)); // Expected: [1, 2, 3, 4, 5]

        System.out.println("Question 3 ");
        // Test Case 1
        int[] arrayq3_1 = {9, 8, 7, 6};
        modifiedCountingSort(arrayq3_1);
        System.out.println(Arrays.toString(arrayq3_1)); // Expected: [6, 7, 8, 9]

        // Test Case 2
        int[] arrayq3_2 = {5, 3, 10, 2, 8};
        modifiedCountingSort(arrayq3_2);
        System.out.println(Arrays.toString(arrayq3_2)); // Expected: [2, 3, 5, 8, 10]

        // Test Case 3
        int[] arrayq3_3 = {1, 2, 3, 4, 5};
        modifiedCountingSort(arrayq3_3);
        System.out.println(Arrays.toString(arrayq3_3)); // Expected: [1, 2, 3, 4, 5]

        // Test Case 4
        int[] arrayq3_4 = {5, 4, 3, 2, 1};
        modifiedCountingSort(arrayq3_4);
        System.out.println(Arrays.toString(arrayq3_4)); // Expected: [1, 2, 3, 4, 5]

        // Test Case 5
        int[] arrayq3_5 = {10, 5, 8, 2, 7};
        modifiedCountingSort(arrayq3_5);
        System.out.println(Arrays.toString(arrayq3_5)); // Expected: [2, 5, 7, 8, 10]

        // Test Case 6
        int[] arrayq3_6 = {-5, -3, -10, -2, -8};
        modifiedCountingSort(arrayq3_6);
        System.out.println(Arrays.toString(arrayq3_6)); // Expected: [-10, -8, -5, -3, -2]

        // Test Case 7
        int[] arrayq3_7 = {-1, -2, -3, -4, -5};
        modifiedCountingSort(arrayq3_7);
        System.out.println(Arrays.toString(arrayq3_7)); // Expected: [-5, -4, -3, -2, -1]

        // Test Case 8
        int[] arrayq3_8 = {10, -5, 8, -2, 7};
        modifiedCountingSort(arrayq3_8);
        System.out.println(Arrays.toString(arrayq3_8)); // Expected: [-5, -2, 7, 8, 10]

        System.out.println("Question 4 Test Cases");
        // Test Case 1
        int[] arrayq4_1 = {34, 12, 7, 43, 55, 97, 41, 28, 2, 62};
        mountainSort(arrayq4_1);
        System.out.println(Arrays.toString(arrayq4_1)); // Expected: [2, 7, 12, 28, 34, 97, 62, 55, 43, 41]

        // Test Case 2
        int[] arrayq4_2 = {10, 8, 6, 4, 2, 1, 3, 5, 7, 9};
        mountainSort(arrayq4_2);
        System.out.println(Arrays.toString(arrayq4_2)); // Expected: [1, 2, 3, 4, 5, 10, 9, 8, 7, 6]

        // Test Case 3
        int[] arrayq4_3 = {-5, -3, -10, -2, -8, -1, -4, -6, -7, -9};
        mountainSort(arrayq4_3);
        System.out.println(Arrays.toString(arrayq4_3)); // Expected: [-10, -9, -8, -7, -6, -5, -1, -2, -3, -4]

        // Test Case 4
        int[] arrayq4_4 = {5, 3, 10, 2, 8, 1, 4, 6, 7, 9};
        mountainSort(arrayq4_4);
        System.out.println(Arrays.toString(arrayq4_4)); // Expected: [1, 2, 3, 4, 5, 10, 9, 8, 7, 6]

        // Test Case 5
        int[] arrayq4_5 = {15, 13, 20, 12, 18, 11, 14, 16, 17, 19};
        mountainSort(arrayq4_5);
        System.out.println(Arrays.toString(arrayq4_5)); // Expected: [11, 12, 13, 14, 15, 20, 19, 18, 17, 16]

        //Test Case 6
        int[] arrayq4_6 = {1,2,5,8,-11,-103,102,98,69,15};
        mountainSort(arrayq4_6);
        System.out.println(Arrays.toString(arrayq4_6));

    }

}