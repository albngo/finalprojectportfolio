# Create database script for Forum App

# Create the database
CREATE DATABASE myForumApp;
USE myForumApp;

# Create the tables
CREATE TABLE users (
    user_id INT AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE,
    PRIMARY KEY(user_id)
);

CREATE TABLE topics (
    topic_id INT AUTO_INCREMENT,
    topic_name VARCHAR(50) UNIQUE,
    PRIMARY KEY(topic_id)
);

CREATE TABLE posts (
    post_id INT AUTO_INCREMENT,
    content TEXT,
    user_id INT,
    topic_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY(post_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (topic_id) REFERENCES topics(topic_id)
);

# Create the app user and give it access to the database
CREATE USER 'appuser'@'localhost' IDENTIFIED WITH mysql_native_password BY 'app2027';
GRANT ALL PRIVILEGES ON myForumApp.* TO 'appuser'@'localhost';
