-- Insert data into the tables

USE myForumApp;

-- Insert new sample users
INSERT INTO users (username) VALUES ('alice'), ('bob'), ('charlie');

-- Insert new sample topics
INSERT INTO topics (topic_name) VALUES ('Music', 'Movies', 'Travel');

-- Insert new sample posts
INSERT INTO posts (content, user_id, topic_id) VALUES
    ('Favorite music genres?', 1, 4),
    ('Latest movie recommendations?', 2, 5),
    ('Best travel destinations in 2023?', 3, 6),
    ('Any music festivals happening?', 1, 4),
    ('Discussing classic movies.', 2, 5);
