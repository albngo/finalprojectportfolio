// Export a function that sets up routes for the shop using the provided Express app and shop data
module.exports = function(app, shopData) {
    // Handle routes for different pages
    // Home page route
    app.get('/', function(req, res) {
        res.render('index.ejs', shopData); // Render the 'index.ejs' template with shop data
    });
    // About page route
    app.get('/about', function(req, res) {
        res.render('about.ejs', shopData); // Render the 'about.ejs' template with shop data
    });
    // Search page route
    app.get('/search', function(req, res) {
        res.render("search.ejs", shopData); // Render the 'search.ejs' template with shop data
    });
    // Search result page route
    app.get('/searchresult', function(req, res) {
        // Get the search term from the query parameter
        let searchKeyword = req.query.keyword;
        // SQL query to get books containing the search term
        let sqlquery = "SELECT * FROM books WHERE name LIKE '%" + searchKeyword + "%'";
        // Execute SQL query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.send('Error');
            }
            // Create a new data object with updated book data and search keyword
            let newData = Object.assign({}, shopData, {
                availableBooks: result,
                searchKeyword: searchKeyword
            });
            // Render the 'searchresult.ejs' template with the updated data
            res.render("searchresult.ejs", newData);
        });
    });
    // Register page route
    app.get('/register', function(req, res) {
        res.render('register.ejs', shopData); // Render the 'register.ejs' template with shop data
    });
    // Registered page route (handling POST request)
    app.post('/registered', function(req, res) {
        // Save user registration data in the database
        res.send('Hello ' + req.body.first + ' ' + req.body.last + ' you are now registered! We will send an email to you at ' + req.body.email);
    });
    // List page route
    app.get('/list', function(req, res) {
        // SQL query to get all books from the database
        let sqlquery = "SELECT * FROM books";
        // Execute SQL query
        db.query(sqlquery, (err, result) => {
            if (err) {
                res.redirect('./');
            }
            // Update the 'list.ejs' template with the updated book data
            let newData = Object.assign({}, shopData, { availableBooks: result });
            console.log(newData);
            res.render("list.ejs", newData);
        });
    });
    // Addbook page route
    app.get('/addbook', function(req, res) {
        res.render('addbook.ejs', shopData); // Render the 'addbook.ejs' template with shop data
    });
    // Bookadded page route (handling POST request)
    app.post('/bookadded', function(req, res) {
        // Save new book data in the database
        let sqlquery = "INSERT INTO books (name, price) VALUES (?,?)";
        let newrecord = [req.body.name, req.body.price];
        // Execute SQL query
        db.query(sqlquery, newrecord, (err, result) => {
            if (err) {
                return console.error(err.message);
            } else {
                res.send('This book is added to the database, name: ' + req.body.name + ' price ' + req.body.price);
            }
        });
    });
    // Bargainbooks page route
    app.get('/bargainbooks', function(req, res) {
        // SQL query to get books priced less than £20
        let sqlquery = "SELECT * FROM books WHERE price < 20";
        // Execute SQL query
        db.query(sqlquery, (err, bargainBooks) => {
            if (err) {
                console.error(err);
                res.redirect('./');
            }
            // Render the 'bargainbooks.ejs' template with the bargain book data
            let newData = Object.assign({}, shopData, { bargainBooks: bargainBooks });
            res.render("bargainbooks.ejs", newData);
        });
    });
}
