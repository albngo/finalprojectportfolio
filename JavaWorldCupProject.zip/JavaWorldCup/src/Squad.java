import java.util.ArrayList;
// This class is used to store the data for each squad in the tournament (i.e. the team name, manager and players) and to provide methods to access this data from other classes in the program (i.e. the Main class)
public class Squad {
    // Squad attributes
    private String teamName;
    private ArrayList<Player> players;
    private Manager manager;
    // Constructor for Squad class (superclass) - used by Team class (inherits from Squad)
    Squad(String teamName, Manager manager){
        this.teamName = teamName;
        this.manager = manager;
        players = new ArrayList<>();
    }
    // This method is used to add a player to the squad
    public void addPlayer(Player p){
        players.add(p);
    }
    //get a player object by surname
    public Player getPlayer(String surname){
        for(Player p: players){
            if(p.getSurname().equals(surname)){
                return p;
            }
        }
        return null;
    }
    //get a player object by index
    public Player getPlayer(int n){
        return players.get(n);
    }
    //get the number of players in the squad
    public String getTeamName() {
        return teamName;
    }
    //get the manager of the squad
    public Manager getManager() {
        return manager;
    }
    //get the players in the squad
    public ArrayList<Player> getPlayers() {
        return players;
    }
}
