public class Team extends Squad{
    // Constructor for Team class that takes in a team name and a manager object and passes them to the super class constructor (Squad) to create a new team object with a team name and manager.
    Team(String teamName, Manager manager) {
        super(teamName, manager);
    }
}
