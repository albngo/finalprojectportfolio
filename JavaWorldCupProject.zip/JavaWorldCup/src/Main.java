// Here we import all the necessary packages for our program to run properly
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Comparator;
import java.util.Collections;
import java.util.Random;
// This is the main class of our program which will be used to run the tournament and load the data from the csv files into the program
public class Main {
    public static Squad[] squads = new Squad[32];
    public static void main(String[] args) {
        // Load managers and players
        loadManagers("Managers.csv");
        loadPlayers("Players.csv");
        runTournament(); // Run the tournament
        // Now squads array should be populated with data from both files
    }
    // This method is used to load the managers from the csv file into the program
    public static void loadManagers(String fileName) {
        try {
            Scanner scanner = new Scanner(new File(fileName));
            scanner.nextLine(); // Skip header row
            // This while loop is used to read the data from the csv file and store it in the squads array
            int index = 0;
            while (scanner.hasNextLine() && index < squads.length) {
                String[] data = scanner.nextLine().split(",");
                squads[index] = new Squad(data[2], new Manager(data[0], data[1], data[2], data[3],
                        Double.parseDouble(data[4]), Double.parseDouble(data[5]),
                        Double.parseDouble(data[6]), Double.parseDouble(data[7])));
                index++;
            }
            // This closes the scanner
            scanner.close();
        // This catches the exception if the file is not found
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    // This method is used to load the players from the csv file into the program
    public static void loadPlayers(String fileName) {
        try {
            Scanner scanner = new Scanner(new File(fileName));
            scanner.nextLine(); // Skip header row
            // This while loop is used to read the data from the csv file and store it in the squads array
            int index = 0;
            while (scanner.hasNextLine() && index < squads.length) {
                String[] data = scanner.nextLine().split(",");
                squads[index].addPlayer(new Player(data[0], data[1], data[2], data[3],
                        Double.parseDouble(data[4]), Double.parseDouble(data[5]),
                        Double.parseDouble(data[6]), Double.parseDouble(data[7]),
                        Double.parseDouble(data[8]), Double.parseDouble(data[9]),
                        Double.parseDouble(data[10]), Double.parseDouble(data[11]),
                        Double.parseDouble(data[12]), Double.parseDouble(data[13])));
                index++;
            }
            scanner.close();
        // This catches the exception if the file is not found
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    // This method is used to get the team from the squad and manager data that has been loaded into the program from the csv files
    public static Team getTeam(Squad squad) {
        // Get the manager and players from the squad
        Manager manager = squad.getManager();
        String preferredFormation = manager.getFavouredFormation();
        ArrayList<Player> players = squad.getPlayers();
        // Sort players based on overall performance (average of all attributes)
        Collections.sort(players, Comparator.comparingDouble(Player::calculateOverallPerformance).reversed());
        // Create a new team
        Team team = new Team(squad.getTeamName(), manager);
        // Form the team based on the preferred formation
        int defenders = Character.getNumericValue(preferredFormation.charAt(0));
        int midfielders = Character.getNumericValue(preferredFormation.charAt(2));
        int forwards = Character.getNumericValue(preferredFormation.charAt(4));
        // Ensure the team has at least one goalkeeper
        int goalkeeperCount = 1;
        // This for loop is used to add the players to the team based on their position
        for (Player player : players) {
            if (player.getPosition().equals("Goalkeeper") && goalkeeperCount > 0) {
                team.addPlayer(player);
                goalkeeperCount--;
            } else if (player.getPosition().equals("Defender") && defenders > 0) {
                team.addPlayer(player);
                defenders--;
            } else if (player.getPosition().equals("Midfielder") && midfielders > 0) {
                team.addPlayer(player);
                midfielders--;
            } else if (player.getPosition().equals("Forward") && forwards > 0) {
                team.addPlayer(player);
                forwards--;
            }
            // Break the loop when the team is complete
            if (defenders == 0 && midfielders == 0 && forwards == 0 && goalkeeperCount == 0) {
                break;
            }
        }
        return team;
    }
    // This method is used to run the tournament
    public static void runTournament() {
        // Run the group stage
        ArrayList<Squad> topTeams = runGroupStage();
        // Display the top teams from the group stage
        System.out.println("\nTop Teams from Group Stage:");
        for (Squad squad : topTeams) {
            System.out.println(squad.getTeamName() + " (" + squad.getManager().getFavouredFormation() + ")");
        }
        // Run the knockout stages
        Squad winner = runKnockoutStages(topTeams);
        // Display the winner of the tournament
        System.out.println("\nTournament Winner: " + winner.getTeamName());
    }
    // This method is used to run the group stage of the tournament
    private static ArrayList<Squad> runGroupStage() {
        ArrayList<Squad> topTeams = new ArrayList<>();
        // Simulate matches in the group stage
        for (int group = 1; group <= 8; group++) {
            ArrayList<Squad> groupTeams = new ArrayList<>();
            // Select teams for the group
            for (int i = 0; i < 4; i++) {
                groupTeams.add(squads[(group - 1) * 4 + i]); // Adjust index accordingly
            }
            // Simulate matches within the group
            for (int i = 0; i < 6; i++) {
                Squad squad1 = groupTeams.get(i % 4);
                Squad squad2 = groupTeams.get((i + 1) % 4);
                // Simulate match and update results
                simulateMatch(squad1, squad2);
            }
            // Sort teams based on performance (for simplicity, use random values)
            groupTeams.sort(Comparator.comparingDouble(team -> Math.random()));
            // Add the top two teams from each group to the topTeams list
            topTeams.add(groupTeams.get(0));
            topTeams.add(groupTeams.get(1));
        }
        return topTeams;
    }
    // This method is used to run the knockout stages of the tournament
    private static Squad runKnockoutStages(ArrayList<Squad> topTeams) {
        // Simulate knockout stages (quarterfinals, semifinals, and finals)
        for (int i = 0; i < 6; i += 2) {
            Squad squad1 = topTeams.get(i);
            Squad squad2 = topTeams.get(i + 1);
            // Simulate match and update results
            simulateMatch(squad1, squad2);
        }
        // Return the winner of the tournament
        return topTeams.get(5);
    }
    // This method is used to simulate a match between two teams
    private static void simulateMatch(Squad squad1, Squad squad2) {
        // Simulate match and update results
        Random random = new Random();
        int winnerIndex = random.nextInt(2);
        if (winnerIndex == 0) {
            System.out.println(squad1.getTeamName() + " beats " + squad2.getTeamName());
        } else {
            System.out.println(squad2.getTeamName() + " beats " + squad1.getTeamName());
        }
    }
}
