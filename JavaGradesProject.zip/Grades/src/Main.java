public class Main {
    public static void main(String[] args) {
        // Define the coursework weighting and student grades
        double[] weighting = {0.15, 0.15, 0.30, 0.40};
        int[] studentGrades = {63, 67, 56, 71};

        // Calculate the final module mark
        double finalMark = 0.0;
        for (int i = 0; i < weighting.length; i++) {
            finalMark += weighting[i] * studentGrades[i];
        }

        // Determine the classification based on the final module mark
        String classification;
        if (finalMark >= 70) {
            classification = "First Class";
        } else if (finalMark >= 60) {
            classification = " 2:1";
        } else if (finalMark >= 50) {
            classification = "2:2";
        } else if (finalMark >= 40) {
            classification = "Third";
        } else {
            classification = "Fail";
        }

        // Display the final module mark and classification
        System.out.println("Final Module Mark: " + finalMark);
        System.out.println("Classification: " + classification);
    }
}
