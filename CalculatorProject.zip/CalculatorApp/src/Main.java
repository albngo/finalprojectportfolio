//we import all swing related libraries, is used to create window-based applications
//we import all awt related libraries, is an API to develop GUIs
//we import all event related libraries, contains event classes and listener interfaces
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main implements ActionListener{

    //JFrames allow us to create a window on the screen like a GUI almost
    //we create the inital JFrame and name it frame
    JFrame frame;
    //allows us to write on the main frame
    JTextField textfield;
    //creates the array of buttons that we will use, so numbers 0-9, all function buttons as well
    JButton[] numberButtons = new JButton[10];
    JButton[] functionButtons = new JButton[9];
    //we declare the variable names for each function button, there are 9 in total
    //addButton adds, subButton subtracts, mulButton multiplies, divButton divides
    JButton addButton, subButton, mulButton, divButton;
    //decButton is to put the decimal point, equButton is equals, delButton is to delete, clrButton is to clear the calculator, negButton is to input negative numbers
    JButton decButton, equButton, delButton, clrButton, negButton;
    //the JPanel stores groups of components in a container, allows us to put the buttons on the frame
    JPanel panel;

    //we create a global font variable so we dont need to declare it each time, chose arial because its superior
    Font myFont = new Font("Arial", Font.BOLD,30);

    //initialised some initial variables so that the calculator starts off with 0 in it.
    double num1 = 0, num2 = 0, result = 0;
    char operator;
    //create a new constructor with the same name as our java file
    Main(){

        //we create the frame, aka the calculator app, we give it a title, we tell it what to do when we close it,we set the size, and we remove its layout so we can mess with it later
        frame = new JFrame("Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 550);
        frame.setLayout(null);

        //here we create a text field so we can see what we are typing and the operations we are doing, we set its location and size, we set the font for it to use, which we already declared as a global variable earlier, we also prevent it from being edited by the keyboard, we can still edit it when we have the buttons
        textfield = new JTextField();
        textfield.setBounds(50, 25, 300, 50);
        textfield.setFont(myFont);
        textfield.setEditable(false);

        //we created new buttons to contain the functions we need
        addButton = new JButton("+");
        subButton = new JButton("-");
        mulButton = new JButton("*");
        divButton = new JButton("/");
        decButton = new JButton(".");
        equButton = new JButton("=");
        delButton = new JButton("Del");
        clrButton = new JButton("AC");
        negButton = new JButton("-/+");

        //here we add each of the new function buttons we made into the functionButtons array so they can be stored easily
        functionButtons[0] = addButton;
        functionButtons[1] = subButton;
        functionButtons[2] = mulButton;
        functionButtons[3] = divButton;
        functionButtons[4] = decButton;
        functionButtons[5] = equButton;
        functionButtons[6] = delButton;
        functionButtons[7] = clrButton;
        functionButtons[8] = negButton;


        //this for loop iterates over our array so we can access each button in a more streamlined way
        //we also set the font so we can see them in the better font
        //focusability is the box highlight that appears when you press a button
        for(int i = 0; i < 9; i++){
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
            functionButtons[i].setFocusable(false);
        }

        //this for loop iterates over our number buttons array so it displays all the number buttons, we create the button in here so that we dont need to do each button separately, we set font, and focusability as well
        //the action listener makes it so that the program knows which object is being worked on when a component is clicked
        for(int i = 0; i < 10; i++){
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(myFont);
            numberButtons[i].setFocusable(false);
        }

        //we set the delete and clear button here separately because they are bigger and dont follow same format as the other buttons
        negButton.setBounds(50, 430, 100, 50);
        delButton.setBounds(150, 430, 100, 50);
        clrButton.setBounds(250, 430, 100, 50);

        //here we created a panel where we will put our buttons, we set its location and size, we also gave it a grid structure with 4 columns and 4 rows, with 10 pixels gap between the elements
        panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4,4,10,10));

        //here we added each button in the specific layout we want bearing in mind its a 4x4 grid, where it fills out top row left to right as we go down, then the next row and the next and then the last row
        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addButton);
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(subButton);
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(mulButton);
        panel.add(decButton);
        panel.add(numberButtons[0]);
        panel.add(equButton);
        panel.add(divButton);


        frame.add(panel);
        //we then add the buttons to the frame so they can be seen and interacted with
        frame.add(negButton);
        frame.add(delButton);
        frame.add(clrButton);
        //we then add the text field into our calculator frame
        frame.add(textfield);
        //we make the whole window now visible
        frame.setVisible(true);

    }

    public static void main(String[] args) {

        //we add the new constructor in the main method so it will run
        Main calc = new Main();

    }

    //the action event records what happens, like if something is clicked, then the listener takes it and stores it/uses it in the program, 'e' is just a variable name, usually short for event, but can be anything
    @Override
    public void actionPerformed(ActionEvent e) {

        //here we created a for loop so that each number that is pressed will be recognised and its value will be i, which is the array index, which in our case matches up perfectly with the number value of each button
        for(int i = 0; i < 10; i++){
            if(e.getSource() == numberButtons[i]){
                textfield.setText(textfield.getText().concat(String.valueOf(i)));

            }
        }
        //here we did a similar thing but for the decimal button, since there is only one decimal button, we dont need a for loop
        if(e.getSource() == decButton){
            textfield.setText(textfield.getText().concat("."));
        }
        //similar to the decimal button, here we made it so that it takes the number the user presses and assigns it to num1, it will also clear the text field so we can keep doing operations
        if(e.getSource() == addButton){
            num1 = Double.parseDouble(textfield.getText());
            operator = '+';
            textfield.setText("");
        }
        //similar to addButton, does exact same thing
        if(e.getSource() == subButton){
            num1 = Double.parseDouble(textfield.getText());
            operator = '-';
            textfield.setText("");
        }
        //same as subButton
        if(e.getSource() == mulButton){
            num1 = Double.parseDouble(textfield.getText());
            operator = '*';
            textfield.setText("");
        }
        //same as mulButton
        if(e.getSource() == divButton){
            num1 = Double.parseDouble(textfield.getText());
            operator = '/';
            textfield.setText("");
        }
        //equals button is slightly different, we need it to compare the operator and see which operator the user has used, so that it does the necessary function
        if(e.getSource() == equButton){
            num2 = Double.parseDouble(textfield.getText());

            //we use a switch/case function here so that instead of writing multiple else if statements, this way the code is faster and more streamlined and it compares all operators in one step
            switch(operator){
                case'+':
                    result = num1 + num2;
                    break;
                case'-':
                    result = num1 - num2;
                    break;
                case'*':
                    result = num1 * num2;
                    break;
                case'/':
                    result = num1 / num2;
                    break;
            }
            //here we output the result at the end of the operations so that the user can see what they did
            textfield.setText(String.valueOf(result));
            num1 = result;
        }
        //we created the clear button, just sets the textfield to an empty text
        if(e.getSource() == clrButton) {
            textfield.setText("");
        }
        //the delete button sets the text to an empty character at the index of the string length which means it checks the last character and deletes it
        if(e.getSource() == delButton){
            String string = textfield.getText();
            textfield.setText("");
            for(int i = 0;i < string.length() - 1;i++){
                textfield.setText(textfield.getText()+string.charAt(i));
            }
        }
        //for the negative button, it will take what is inside the calculator and multiply it by -1 to make it negative, if it is already negative it will make it positive
        if(e.getSource() == negButton){
            double temp = Double.parseDouble(textfield.getText());
            temp*=-1;
            textfield.setText(String.valueOf(temp));
            }
        }
}
