/*
	The Game Project Part 4 - Character Interaction
*/


//we declare all variables that will be used here, in chunks for variables used in similar/same places
var gameChar_x; //x position of game character
var gameChar_y; //y position of game character
var floorPos_y; //position of the floor

var canyons; //canyons object
var canyon; //death trap canyon
var isPlummeting; //controls canyon interaction

var isLeft; //allows left movement
var isRight; //allows right movement
var isFalling; //creates a sense of gravity
var collectables; //variable for object with all collectables
var flagpole; //variable for flag object

var trees_x; //array of tree objects
var treePos_x; //x position for tree
var treePos_y; //y position for tree

var clouds; //array of cloud objects

var mountains; //array of mountain objects

var cameraPosX; //the x position of the camera, allows it to move with character

var levelComplete; //level complete state
var gameOver; //game over state

var gameScore; //score counter for collectable items
var maxGameScore; //maximum score that can be achieved

var mountainx300; //used for anchoring mountains better, x position
var mountainx400; //used for anchoring mountains better, x position
var mountainx500; //used for anchoring mountains better, x position
var mountainx600; //used for anchoring mountains better, x position

var mountainy100; //used for anchoring mountains better, y position
var mountainy200; //used for anchoring mountains better, y position
var mountainy300; //used for anchoring mountains better, y position

var treex300; //used for anchoring trees better, x position
var treex400; //used for anchoring trees better, x position

var treey100; //used for anchoring trees better, y position

var cloudx250; //used for anchoring clouds better, x position
var cloudy100; //used for anchoring clouds better, y position

var oof;


function setup()
{
	//we create the canvas and initialise all objects, variables and arrays here
    createCanvas(1024, 576);
	floorPos_y = height * 3/4;
	gameChar_x = width/2;
	gameChar_y = floorPos_y;
    cameraPosX = 0;

	//array of canyon positions
    canyons = [
        {x_pos: 200, width: 150},
        {x_pos: 1000, width: 70},
        {x_pos: 2000, width: 100}         
    ]
    
    //death trap canyon that cant be cleared
    canyon = {
        x_pos: -1000,
        width: 170 
    };
    
    //array of tree positions
    trees_x = [-2000, -2800, -3900, -4500, -5000, -6900, -800, 400, 1100, 2000, 2800, 3900, 4500, 5000, 6900];
    treePos_y = floorPos_y;
    
    //initialise vairables used for movement and game states
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    levelComplete = false;
    gameOver = false;
    gameScore = 0;
    maxGameScore = false;
    
    soundFormats('mp3', 'ogg');
    oof = loadSound('oof.mp3');
    
    mountainx300 = 300; //used for anchoring
    mountainx400 = 400; //used for anchoring
    mountainx500 = 500; //used for anchoring
    mountainx600 = 600; //used for anchoring
    mountainy100 = 100; //used for anchoring
    mountainy200 = 200; //used for anchoring
    mountainy300 = 300; //used for anchoring
    
    treex300 = 300; //used for anchoring
    treex400 = 400; //used for anchoring
    treey100 = 100; //used for anchoring
    
    cloudx250 = 250; //used for anchoring
    cloudy100 = 100; //used for anchoring
    
    //array of collectable items, each item is within an object to make it easier to reference later
    collectables = [
        {x_pos: 780,y_pos: 400,size: 50,isFound: false},
        {x_pos: 980,y_pos: 400,size: 50,isFound: false},
        {x_pos: 1530,y_pos: 400,size: 50,isFound: false},
        {x_pos: 1780,y_pos: 400,size: 50,isFound: false},
        {x_pos: 1930,y_pos: 400,size: 50,isFound: false},
        {x_pos: 2480,y_pos: 400,size: 50,isFound: false}
    ]
    
    //object with flagpole attributes
    flagpole = {
        x_pos: 2700,
        y_pos: floorPos_y,
        size: 1,
        isReached: false
    }
    
    //object with tree attributes to initialise first tree
    tree = {
        x_pos: width/2,
        y_pos: height/2,
        size: 1
    }
    
    //array of cloud objects with all attributes for each cloud
    clouds = [
        {x_pos: 0, y_pos: 0, size: 1,},
        {x_pos: 370, y_pos: 10, size: 1,},
        {x_pos: 720, y_pos: 25, size: 1,},
        {x_pos: 1060, y_pos: 25, size: 1,},
        {x_pos: 3060, y_pos: 25, size: 1,},
        {x_pos: 4530, y_pos: 25, size: 1,},
        {x_pos: 5780, y_pos: 25, size: 1,},
        {x_pos: 6940, y_pos: 25, size: 1,},
        {x_pos: -350, y_pos: 10, size: 1,},
        {x_pos: -720, y_pos: 25, size: 1,},
        {x_pos: -1080, y_pos: 25, size: 1,},
        {x_pos: -3400, y_pos: 25, size: 1,},
        {x_pos: -4590, y_pos: 25, size: 1,},
        {x_pos: -5730, y_pos: 25, size: 1,},
        {x_pos: -6910, y_pos: 25, size: 1,}
    ]
    
    //array of mountain objects with all attributes for each mountain
    mountains = [
        {x_pos: 0,y_pos: 0,size: 1},
        {x_pos: 1020,y_pos: 0,size: 1},
        {x_pos: 1510,y_pos: 0,size: 1},
        {x_pos: 2195,y_pos: 0,size: 1},
        {x_pos: 3080,y_pos: 0,size: 1},
        {x_pos: 3850,y_pos: 0,size: 1},
        {x_pos: 4550,y_pos: 0,size: 1},
        {x_pos: 5670,y_pos: 0,size: 1},
        {x_pos: 6980,y_pos: 0,size: 1},
        {x_pos: -1020,y_pos: 0,size: 1},
        {x_pos: -1510,y_pos: 0,size: 1},
        {x_pos: -3010,y_pos: 0,size: 1},
        {x_pos: -3840,y_pos: 0,size: 1},
        {x_pos: -4560,y_pos: 0,size: 1},
        {x_pos: -5690,y_pos: 0,size: 1},
        {x_pos: -6930,y_pos: 0,size: 1}
    ]
        
}

function draw()
{
    
    //this allows camera to pan with game character and always keep it centered
    cameraPosX = -gameChar_x + width / 2;
    
	///////////DRAWING CODE//////////

	background(100,155,255); //fill the sky blue


	noStroke();
	fill(0,155,0);
	rect(0, floorPos_y, width, height - floorPos_y); //draw some green ground

	push();
    translate(cameraPosX, 0);
    
    //draw the canyon
	noStroke();
	fill(92, 40, 0);
    for(var i = 0; i < canyons.length; i++){
        rect(canyons[i].x_pos, floorPos_y, canyons[i].width, height - floorPos_y);
    }    
    
    //draws impossible canyon
    noStroke();
    fill(92, 40, 0);
    rect(canyon.x_pos, floorPos_y, canyon.width, height - floorPos_y);

    //controls the speed of the character falling down when met with a canyon
    if(isPlummeting == true){
        gameChar_y +=2; 
    }
    
    //collectable item
    for(var i = 0; i < collectables.length; i++){
    if(collectables[i].isFound == false){
        beginShape();
        stroke(0);
        fill(0,204,204);
        strokeWeight(1);
        vertex((collectables[i].x_pos) * (collectables[i].size / 50),(collectables[i].y_pos + 27) * (collectables[i].size / 50));
        vertex((collectables[i].x_pos + 10) * (collectables[i].size / 50),(collectables[i].y_pos + 17) * (collectables[i].size / 50));
        vertex((collectables[i].x_pos) * (collectables[i].size / 50),(collectables[i].y_pos + 07) * (collectables[i].size / 50));
        vertex((collectables[i].x_pos - 10) * (collectables[i].size / 50),(collectables[i].y_pos + 17) * (collectables[i].size / 50));
        vertex((collectables[i].x_pos) * (collectables[i].size / 50),(collectables[i].y_pos + 27) * (collectables[i].size / 50));
        endShape();
       }
    }
     
    for(var i = 0; i < mountains.length; i++){
         //small mountain bottom
        noStroke();
        fill(92,92,92);
        beginShape();
        vertex(mountains[i].x_pos + mountainx300 + 30 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 71 * mountains[i].size,mountains[i].y_pos + mountainy300 + 54 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 90 * mountains[i].size,mountains[i].y_pos + mountainy300 + 54 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx400 + 31 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 30 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        endShape();

        //small mountain top
        noStroke();
        fill(255,255,255);
        beginShape();
        vertex(mountains[i].x_pos + mountainx300 + 71 * mountains[i].size,mountains[i].y_pos + mountainy300 + 54 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 90 * mountains[i].size,mountains[i].y_pos + mountainy300 + 54 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 81 * mountains[i].size,mountains[i].y_pos + mountainy300 + 36 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 71 * mountains[i].size,mountains[i].y_pos + mountainy300 + 54 * mountains[i].size);
        endShape();

        //big mountain bottom
        noStroke();
        fill(92,92,92);
        beginShape();
        vertex(mountains[i].x_pos + mountainx400 + 31 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx300 + 99 * mountains[i].size,mountains[i].y_pos + mountainy300 + 71 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx400 + 60 * mountains[i].size,mountains[i].y_pos + mountainy200 + 20 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx500 + 20 * mountains[i].size,mountains[i].y_pos + mountainy200 + 20 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 15 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx400 + 31 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        endShape();

        //big mountain top
        noStroke();
        fill(255,255,255);
        beginShape();
        vertex(mountains[i].x_pos + mountainx400 + 60 * mountains[i].size,mountains[i].y_pos + mountainy200 + 20 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx500 + 20 * mountains[i].size,mountains[i].y_pos + mountainy200 + 20 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx400 + 90 * mountains[i].size,mountains[i].y_pos + mountainy100 + 56 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx400 + 60 * mountains[i].size,mountains[i].y_pos + mountainy200 + 20 * mountains[i].size);
        endShape();

        //medium mountain bottom
        noStroke();
        fill(92,92,92);
        beginShape();
        vertex(mountains[i].x_pos + mountainx600 + 15 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx500 + 71 * mountains[i].size,mountains[i].y_pos + mountainy300 + 36 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 * mountains[i].size,mountains[i].y_pos + mountainy200 + 83 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 22 * mountains[i].size,mountains[i].y_pos + mountainy200 + 83 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 95 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 15 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        endShape();

        //medium mountains[i] top
        noStroke();
        fill(255,255,255);
        beginShape();
        vertex(mountains[i].x_pos + mountainx600 * mountains[i].size,mountains[i].y_pos + mountainy200 + 83 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 22 * mountains[i].size,mountains[i].y_pos + mountainy200 + 83 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 + 11 * mountains[i].size,mountains[i].y_pos + mountainy200 + 60 * mountains[i].size);
        vertex(mountains[i].x_pos + mountainx600 * mountains[i].size,mountains[i].y_pos + mountainy200 + 83 * mountains[i].size);
        endShape();

        //Shadows between mountains[i]s
        stroke(0);
        line(mountains[i].x_pos + mountainx300 + 99 * mountains[i].size,mountains[i].y_pos + mountainy300 + 71 * mountains[i].size,
             mountains[i].x_pos + mountainx400 + 31 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
        line(mountains[i].x_pos + mountainx500 + 71 * mountains[i].size,mountains[i].y_pos + mountainy300 + 35 * mountains[i].size,
             mountains[i].x_pos + mountainx600 + 15 * mountains[i].size,mountains[i].y_pos + floorPos_y * mountains[i].size);
    }
    
     //flagpole
    if(flagpole.isReached == false || flagpole.isReached == true || levelComplete == false){
        //flag pedestal
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(flagpole.x_pos + 25 * flagpole.size,flagpole.y_pos * flagpole.size);
        vertex(flagpole.x_pos + 50 * flagpole.size,flagpole.y_pos * flagpole.size);
        vertex(flagpole.x_pos + 47 * flagpole.size,flagpole.y_pos - 12 * flagpole.size);
        vertex(flagpole.x_pos + 28 * flagpole.size,flagpole.y_pos - 12 * flagpole.size);
        vertex(flagpole.x_pos + 25 * flagpole.size,flagpole.y_pos * flagpole.size);
        endShape();

        //flag pole
        noStroke();
        fill(104,104,104);
        beginShape();
        vertex(flagpole.x_pos + 33 * flagpole.size,flagpole.y_pos - 12 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 12 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        vertex(flagpole.x_pos + 33 * flagpole.size,flagpole.y_pos - 96 * flagpole.size);
        vertex(flagpole.x_pos + 33 * flagpole.size,flagpole.y_pos - 12 * flagpole.size);
        endShape();

        //flag top
        stroke(0,0,0);
        fill(0,0,0);
        beginShape();
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 101 * flagpole.size);
        vertex(flagpole.x_pos + 33 * flagpole.size,flagpole.y_pos - 101 * flagpole.size);
        vertex(flagpole.x_pos + 33 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        endShape();
    }
    
    if(flagpole.isReached == true && levelComplete == true){
        //flag flag
        strokeWeight(1);
        stroke(0,0,0);
        fill(255,0,0);
        beginShape();    
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        vertex(flagpole.x_pos + 70 * flagpole.size,flagpole.y_pos - 87 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 77 * flagpole.size);
        vertex(flagpole.x_pos + 42 * flagpole.size,flagpole.y_pos - 97 * flagpole.size);
        endShape(); 
    }
    
    //tree trunk
    for(var i = 0; i < trees_x.length; i++){
        noStroke();
        fill(102,51,0);
        beginShape();
        vertex(trees_x[i] - treex300 - 92 * tree.size,tree.y_pos + treey100 + 44 * tree.size);
        vertex(trees_x[i] - treex300 - 92 * tree.size,tree.y_pos + 57 * tree.size);
        vertex(trees_x[i] - treex300 - 78 * tree.size,tree.y_pos + 57 * tree.size);
        vertex(trees_x[i] - treex300 - 78 * tree.size,tree.y_pos + treey100 + 44 * tree.size);
        endShape();
        //tree right branch
        triangle(trees_x[i] - treex300 - 78 * tree.size,tree.y_pos + treey100 + 2 * tree.size,
                 trees_x[i] - treex300 - 62 * tree.size,tree.y_pos + 92 * tree.size,
                 trees_x[i] - treex300 - 78 * tree.size,tree.y_pos + treey100 + 8 * tree.size);

        //tree left branch
        triangle(trees_x[i] - treex300 - 92 * tree.size,tree.y_pos + treey100 + 8 * tree.size,
                 trees_x[i] - treex400 - 12 * tree.size,tree.y_pos + 94 * tree.size,
                 trees_x[i] - treex300 - 92 * tree.size,tree.y_pos + treey100 + 13 * tree.size);

        //tree leaves
        fill(150,150,0);
        ellipse(trees_x[i] - treex400 * tree.size,tree.y_pos + 62 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex300 - 70 * tree.size,tree.y_pos + 62 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex400 - 07 * tree.size,tree.y_pos + 42 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex300 - 63 * tree.size,tree.y_pos + 42 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex300 - 85 * tree.size,tree.y_pos + 27 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex300 - 85 * tree.size,tree.y_pos + 47 * tree.size,35 * tree.size,35 * tree.size);
        ellipse(trees_x[i] - treex400 - 11 * tree.size,tree.y_pos + 95 * tree.size,15 * tree.size,15 * tree.size);
        ellipse(trees_x[i] - treex300 - 61 * tree.size,tree.y_pos + 91 * tree.size,17 * tree.size,17 * tree.size); 
    }
    
    //Shadow of cloud 1
    for(var i = 0; i < clouds.length; i++){
        noStroke();
        fill(130);
        ellipse(clouds[i].x_pos + cloudx250 - 60 * clouds[i].size,clouds[i].y_pos + cloudy100 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 - 20 * clouds[i].size,clouds[i].y_pos + cloudy100 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 20 * clouds[i].size,clouds[i].y_pos + cloudy100 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 60 * clouds[i].size,clouds[i].y_pos + cloudy100 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);

        //Bottom layer of cloud 1 
        noStroke();
        fill(240);
        ellipse(clouds[i].x_pos + cloudx250 - 55 * clouds[i].size,clouds[i].y_pos + cloudy100 - 8 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 - 15 * clouds[i].size,clouds[i].y_pos + cloudy100 - 8 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 25 * clouds[i].size,clouds[i].y_pos + cloudy100 - 8 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 65 * clouds[i].size,clouds[i].y_pos + cloudy100 - 8 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);

        //Upper layer of cloud 1
        noStroke();
        fill(240);
        ellipse(clouds[i].x_pos + cloudx250 - 35 * clouds[i].size,clouds[i].y_pos + cloudy100 - 35 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 5 * clouds[i].size,clouds[i].y_pos + cloudy100 - 40 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
        ellipse(clouds[i].x_pos + cloudx250 + 45 * clouds[i].size,clouds[i].y_pos + cloudy100 - 35 * clouds[i].size,60 * clouds[i].size,60 * clouds[i].size);
    }
        
	//the game character
	if(isLeft && isFalling)
	{
		// add your jumping-left code
        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //body and arms
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x  - 6,gameChar_y - 47);
        vertex(gameChar_x - 10,gameChar_y - 57);
        vertex(gameChar_x - 12,gameChar_y - 57);
        vertex(gameChar_x  - 6,gameChar_y - 37);
        vertex(gameChar_x  - 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 37);
        vertex(gameChar_x + 11,gameChar_y - 29);
        vertex(gameChar_x + 14,gameChar_y - 29);
        vertex(gameChar_x + 6,gameChar_y - 47);
        endShape();

        //legs
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 5,gameChar_y - 3);
        vertex(gameChar_x,gameChar_y - 20);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 6,gameChar_y - 20);
        endShape();

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 7,gameChar_y - 3);
        vertex(gameChar_x - 11,gameChar_y - 3);
        vertex(gameChar_x - 11,gameChar_y - 1);
        vertex(gameChar_x - 5,gameChar_y - 1);
        vertex(gameChar_x - 5,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x + 8,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 3);
        endShape();
	}
    
	else if(isRight && isFalling)
	{
		// add your jumping-right code
        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //body and arms
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x  - 6,gameChar_y - 47);
        vertex(gameChar_x - 12,gameChar_y - 29);
        vertex(gameChar_x - 10,gameChar_y - 29);
        vertex(gameChar_x  - 6,gameChar_y - 37);
        vertex(gameChar_x  - 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 37);
        vertex(gameChar_x + 14,gameChar_y - 57);
        vertex(gameChar_x + 11,gameChar_y - 57);
        vertex(gameChar_x + 6,gameChar_y - 47);
        endShape();

        //legs
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 5,gameChar_y - 3);
        vertex(gameChar_x,gameChar_y - 20);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 6,gameChar_y - 20);
        endShape();

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x + 9,gameChar_y - 3);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 5,gameChar_y - 1);
        vertex(gameChar_x + 11,gameChar_y - 1);
        vertex(gameChar_x + 11,gameChar_y - 3);
        endShape();
	}
    
	else if(isLeft)
	{
		// add your walking left code
        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //body and arms
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x  - 6,gameChar_y - 47);
        vertex(gameChar_x - 12,gameChar_y - 29);
        vertex(gameChar_x - 10,gameChar_y - 29);
        vertex(gameChar_x  - 6,gameChar_y - 37);
        vertex(gameChar_x  - 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 37);
        vertex(gameChar_x + 11,gameChar_y - 29);
        vertex(gameChar_x + 14,gameChar_y - 29);
        vertex(gameChar_x + 6,gameChar_y - 47);
        endShape();

        //legs
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 5,gameChar_y - 3);
        vertex(gameChar_x,gameChar_y - 20);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 6,gameChar_y - 20);
        endShape();

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 7,gameChar_y - 3);
        vertex(gameChar_x - 11,gameChar_y - 3);
        vertex(gameChar_x - 11,gameChar_y - 1);
        vertex(gameChar_x - 5,gameChar_y - 1);
        vertex(gameChar_x - 5,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x + 8,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 3);
        endShape();
	}
    
	else if(isRight)
	{
		// add your walking right code
        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //body and arms
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x  - 6,gameChar_y - 47);
        vertex(gameChar_x - 12,gameChar_y - 29);
        vertex(gameChar_x - 10,gameChar_y - 29);
        vertex(gameChar_x  - 6,gameChar_y - 37);
        vertex(gameChar_x  - 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 20);
        vertex(gameChar_x + 6,gameChar_y - 37);
        vertex(gameChar_x + 11,gameChar_y - 29);
        vertex(gameChar_x + 14,gameChar_y - 29);
        vertex(gameChar_x + 6,gameChar_y - 47);
        endShape();

        //legs
        noStroke();
        fill(140,140,140);
        beginShape();    
        vertex(gameChar_x - 6,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 5,gameChar_y - 3);
        vertex(gameChar_x,gameChar_y - 20);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 6,gameChar_y - 20);
        endShape();

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x + 9,gameChar_y - 3);
        vertex(gameChar_x + 5,gameChar_y - 3);
        vertex(gameChar_x + 5,gameChar_y - 1);
        vertex(gameChar_x + 11,gameChar_y - 1);
        vertex(gameChar_x + 11,gameChar_y - 3);
        endShape();

	}
	else if(isFalling || isPlummeting)
	{
		// add your jumping facing forwards code
        //body
        noStroke();
        fill(120,70,70);
        rect(gameChar_x - 10,gameChar_y - 47,20,27,3);

        //shoulders
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x - 14,gameChar_y - 47);
        vertex(gameChar_x + 14,gameChar_y - 47);
        vertex(gameChar_x + 16,gameChar_y - 40);
        vertex(gameChar_x - 16,gameChar_y - 40);
        vertex(gameChar_x - 14,gameChar_y - 47);
        endShape();

        //left arm
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x - 16,gameChar_y - 40);
        vertex(gameChar_x - 16,gameChar_y - 59);
        vertex(gameChar_x - 12,gameChar_y - 59);
        vertex(gameChar_x - 10,gameChar_y - 40);
        endShape();

        //right arm
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x + 16,gameChar_y - 40);
        vertex(gameChar_x + 16,gameChar_y - 59);
        vertex(gameChar_x + 12,gameChar_y - 59);
        vertex(gameChar_x + 10,gameChar_y - 40);
        endShape();

        //left leg
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x - 8,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 4,gameChar_y - 3);
        vertex(gameChar_x - 2,gameChar_y - 20);
        endShape();

        //right leg
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x + 8,gameChar_y - 20);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 2,gameChar_y - 20);
        endShape();

        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();    
        vertex(gameChar_x + 8,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 3);
        endShape();

	}
	else
	{
		// add your standing front facing code
        //body
        noStroke();
        fill(120,70,70);
        rect(gameChar_x - 10,gameChar_y - 47,20,27,3);

        //shoulders
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x - 13,gameChar_y - 47);
        vertex(gameChar_x + 13,gameChar_y - 47);
        vertex(gameChar_x + 16,gameChar_y - 40);
        vertex(gameChar_x - 16,gameChar_y - 40);
        vertex(gameChar_x - 13,gameChar_y - 47);
        endShape();

        //left arm
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x - 16,gameChar_y - 40);
        vertex(gameChar_x - 16,gameChar_y - 27);
        vertex(gameChar_x - 12,gameChar_y - 27);
        vertex(gameChar_x - 10,gameChar_y - 40);
        endShape();

        //right arm
        noStroke();
        fill(120,70,70);
        beginShape();
        vertex(gameChar_x + 16,gameChar_y - 40);
        vertex(gameChar_x + 16,gameChar_y - 27);
        vertex(gameChar_x + 12,gameChar_y - 27);
        vertex(gameChar_x + 10,gameChar_y - 40);
        endShape();

        //left leg
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x - 8,gameChar_y - 20);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 4,gameChar_y - 3);
        vertex(gameChar_x - 2,gameChar_y - 20);
        endShape();

        //right leg
        noStroke();
        fill(140,140,140);
        beginShape();
        vertex(gameChar_x + 8,gameChar_y - 20);
        vertex(gameChar_x + 10,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 2,gameChar_y - 20);
        endShape();

        //head
        noStroke();
        fill(253,226,232);
        ellipse(gameChar_x,gameChar_y - 54,12,15);

        //shoes
        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x - 6,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 3);
        vertex(gameChar_x - 10,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 1);
        vertex(gameChar_x - 4,gameChar_y - 3);
        endShape();

        noStroke();
        fill(0,0,0);
        beginShape();
        vertex(gameChar_x + 8,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 3);
        vertex(gameChar_x + 4,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 1);
        vertex(gameChar_x + 10,gameChar_y - 3);
        endShape();

	}
    
    //adds a white outline to the game over/ level complete graphics
    stroke(255,255,255);
    strokeWeight(3);
    
    //allows game over state to trigger game over graphic, only when character falls off screen
    if(gameOver == true && gameChar_y > height){
        textAlign(CENTER);
        textSize(26);
        text("Game Over! Your score was " + gameScore +" points", gameChar_x, height/2);
        text("Refresh the page to play again!", gameChar_x, height/2 + 70);
    }else{ 
        //death trap canyon that you cant jump over :)
        stroke(255,255,255);
        strokeWeight(2);
        textSize(18);
        textAlign(CENTER);
        text("Make it over this and you win no cap", -912, height/2);
        //provocative text haha funny
        stroke(255,255,255);
        strokeWeight(2);
        textSize(16);
        text("Nothing to see here, go back the other way!", -320, height/2);
    }
    
    if(gameChar_y > height && gameChar_y < (height + 20)){
        oof.play();
        
    }
    
    //allows level complete state to trigger level complete graphic when flag is reached
    if(levelComplete == true && gameScore == 6){
        textAlign(CENTER);
        textSize(26);
        text("Level Complete! Your score was " + gameScore +" points", gameChar_x, height/2);
        text("You found 2/2 easter eggs well done", gameChar_x, height/2 + 35);
        text("Refresh the page to play again!", gameChar_x, height/2 + 70);
        oof.play();
        noLoop();
    }else if(levelComplete == true && gameScore == 5){
        textAlign(CENTER);
        textSize(26);
        text("Level Complete! Your score was " + gameScore +" points", gameChar_x, height/2);
        text("You found 1/2 easter eggs well done", gameChar_x, height/2 + 35);
        text("Refresh the page to play again!", gameChar_x, height/2 + 70);
        oof.play();
        noLoop();
    }else if(levelComplete == true && gameScore < 5){
        textAlign(CENTER);
        textSize(26);
        text("Level Complete! Your score was " + gameScore +" points", gameChar_x, height/2);
        text("You found 0/2 easter eggs, try again", gameChar_x, height/2 + 35);
        text("Refresh the page to play again!", gameChar_x, height/2 + 70);
        oof.play();
        noLoop();
    }
    //adds a score counter on the top left of the screen that updates in real time
    noStroke();
    textAlign(LEFT);
    textSize(40);
    text("Score: " + gameScore, gameChar_x - width/2 + 10, 40);
            
    pop();

	///////////INTERACTION CODE//////////
	//Put conditional statements to move the game character below here
    
    //controls speed of left/right movement
    if(isLeft == true && isPlummeting == false && levelComplete == false){
        gameChar_x -=3.2;
    }else if(isRight == true && isPlummeting == false && levelComplete == false){
        gameChar_x +=3.2;
    }

    //controls the jump mechanics of the character
    if(gameChar_y < floorPos_y && levelComplete == false){
        gameChar_y +=2;
        isFalling = true;
    }else{
        isFalling = false;
    }

    //controls the collectable item interaction and allows score to increase by 1 each time a collectable is found
    for(var i = 0; i < collectables.length; i++){
        if(dist(gameChar_x, gameChar_y, (collectables[i].x_pos) * (collectables[i].size / 50), (collectables[i].y_pos + 27) * (collectables[i].size / 50)) < 30){
            if(!collectables[i].isFound){
                gameScore++;
            }
            collectables[i].isFound = true;
        }
    }
    
    //allows flag to change visuals when reached and triggers level complete state when done so
    if(dist(gameChar_x, gameChar_y, (flagpole.x_pos + 33 * flagpole.size), (flagpole.y_pos - 12 * flagpole.size)) < 35){
        flagpole.isReached = true;
        levelComplete = true;
    }

    //plummeting
    for(var i = 0; i < canyons.length; i++){
    if((gameChar_x < canyons[i].x_pos + canyons[i].width && gameChar_x > canyons[i].x_pos) && (gameChar_y >= floorPos_y)){
        isPlummeting = true;
        gameOver = true;
        }
    }
    
    if((gameChar_x < canyon.x_pos + canyon.width && gameChar_x > canyon.x_pos) && (gameChar_y >= floorPos_y)){
        isPlummeting = true;
        gameOver = true;
    }
}


function keyPressed()
{
	// if statements to control the animation of the character when
	// keys are pressed.

	//open up the console to see how these work
	console.log("keyPressed: " + key);
	console.log("keyPressed: " + keyCode);
    
    //controls the left, right and jumping movement, also prevents double jumping and stops movement when level is complete or game is over
    if((key == "a" || key == "ArrowLeft") && (isPlummeting == false) && (levelComplete == false)){
        isLeft = true;
    }else if((key == "d" || key == "ArrowRight") && (isPlummeting == false) && (levelComplete == false)){
        isRight = true;
    }else if((key == "w" || key == "ArrowUp" || keyCode == "32") && (gameChar_y == floorPos_y) && (isPlummeting == false) && (levelComplete == false)){
        gameChar_y = gameChar_y - 100;
    }
}

function keyReleased()
{
	// if statements to control the animation of the character when
	// keys are released.

	console.log("keyReleased: " + key);
	console.log("keyReleased: " + keyCode);
    
    //stops moving when key is released
    if(key == "a" || key == "ArrowLeft"){
        isLeft = false;
    }else if(key == "d" || key == "ArrowRight"){
        isRight = false;
    }
}
