import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main extends JFrame {

    private JLabel targetWordLabel;
    private JLabel guessesRemainingLabel;
    private JTextField letterField;
    private JButton guessButton;
    private JPanel keyboardPanel;
    private ArrayList<CustomButton> keyboardButtons; // Use CustomButton instead of JButton

    private String targetWord;
    private int guessesRemaining;
    private ArrayList<Character> guessedLetters;
    private ArrayList<String> targetWords = new ArrayList<>();

    public Main() {

        setTitle("Hangman Game");
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));
        getContentPane().setBackground(Color.DARK_GRAY); // Set background color

        targetWordLabel = new JLabel("Target Word: ");
        targetWordLabel.setFont(new Font("Arial", Font.PLAIN, 24)); // Set font size to 24
        targetWordLabel.setForeground(Color.WHITE); // Set text color
        add(targetWordLabel);

        guessesRemainingLabel = new JLabel("Guesses Remaining: ");
        guessesRemainingLabel.setFont(new Font("Arial", Font.PLAIN, 24)); // Set font size to 24
        guessesRemainingLabel.setForeground(Color.WHITE); // Set text color
        add(guessesRemainingLabel);

        letterField = new JTextField();
        letterField.setFont(new Font("Arial", Font.PLAIN, 24)); // Set font size to 24
        add(letterField);

        guessButton = new JButton("Guess");
        guessButton.setFont(new Font("Arial", Font.PLAIN, 24)); // Set font size to 24
        guessButton.setBackground(Color.WHITE); // Set background color
        guessButton.setForeground(Color.DARK_GRAY); // Set text color
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                processGuess();
            }
        });
        add(guessButton);

        // Create keyboard
        createKeyboard();

        // Load words from file
        loadWords();
        // Start the game
        startGame();
    }

    private void createKeyboard() {
        keyboardPanel = new JPanel();
        keyboardPanel.setLayout(new GridLayout(3, 10)); // Adjust the layout as needed
        keyboardPanel.setBackground(Color.GRAY); // Set background color

        keyboardButtons = new ArrayList<>();

        // Create buttons for each letter of the alphabet
        for (char c = 'A'; c <= 'Z'; c++) {
            CustomButton button = new CustomButton(String.valueOf(c)); // Use CustomButton
            button.setFont(new Font("Arial", Font.PLAIN, 18)); // Set font size for the keyboard buttons
            button.setBackground(Color.WHITE); // Set background color
            button.setForeground(Color.DARK_GRAY); // Set text color
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Process the guess when a keyboard button is clicked
                    letterField.setText(button.getText());
                    processGuess();
                }
            });
            keyboardButtons.add(button);
            keyboardPanel.add(button);
        }

        add(keyboardPanel);
    }

    private void resetKeyboard() {
        for (CustomButton button : keyboardButtons) {
            button.setEnabled(true);
            button.setBackground(Color.WHITE); // Reset background color
        }
    }

    private void loadWords() {
        try {
            Scanner in = new Scanner(new File("Hangman/src/wordlist.txt"));
            while (in.hasNextLine()) {
                String word = in.nextLine().trim();
                if (word.length() >= 7 && word.length() <= 10) {
                    targetWords.add(word);
                    System.out.println(word);
                }
            }
            in.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void startGame() {
        resetKeyboard(); // Reset keyboard buttons

        if (targetWords.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No valid words found in the word list.");
            System.exit(1);
        }

        targetWord = getRandomWord();
        guessedLetters = new ArrayList<>();
        guessesRemaining = 7;

        updateUI();
    }

    private String getRandomWord() {
        Random random = new Random();
        return targetWords.get(random.nextInt(targetWords.size()));
    }

    private void processGuess() {
        String letter = letterField.getText().toLowerCase();

        if (letter.length() != 1 || !Character.isLetter(letter.charAt(0))) {
            JOptionPane.showMessageDialog(this, "Please enter a valid single letter.");
            letterField.setText("");
            return;
        }

        char guess = letter.charAt(0);

        if (guessedLetters.contains(guess)) {
            JOptionPane.showMessageDialog(this, "You have already guessed this letter.");
            letterField.setText("");
            return;
        }

        guessedLetters.add(guess);

        if (!targetWord.contains(letter)) {
            guessesRemaining--;
        }

        updateUI();

        if (isGameOver()) {
            endGame();
        }

        // Clear the text field
        letterField.setText("");
    }

    private void updateUI() {
        targetWordLabel.setText("Target Word: " + getMaskedWord());
        guessesRemainingLabel.setText("Guesses Remaining: " + guessesRemaining);

        // Disable guessed letters in the keyboard
        for (CustomButton button : keyboardButtons) {
            char letter = Character.toLowerCase(button.getText().charAt(0)); // Convert to lowercase
            if (guessedLetters.contains(letter)) {
                button.setGuessed(true); // Set button as guessed
            } else {
                button.setGuessed(false); // Set button as not guessed
            }
        }
    }


    private String getMaskedWord() {
        StringBuilder maskedWord = new StringBuilder();

        for (char c : targetWord.toCharArray()) {
            if (guessedLetters.contains(c)) {
                maskedWord.append(c);
            } else {
                maskedWord.append('_');
            }
            maskedWord.append(' ');
        }
        return maskedWord.toString();
    }

    private boolean isGameOver() {
        // Check if all letters in the target word have been guessed
        boolean wordGuessed = true;
        for (char c : targetWord.toCharArray()) {
            if (!guessedLetters.contains(c)) {
                wordGuessed = false;
                break;
            }
        }

        // Check if the number of remaining guesses is zero or negative
        boolean outOfGuesses = guessesRemaining <= 0;
        // Return true if either condition is met
        return wordGuessed || outOfGuesses;
    }

    private void endGame() {
        if (isWordGuessed()) {
            JOptionPane.showMessageDialog(this, "Congratulations! You've guessed the word: " + targetWord);
        } else {
            JOptionPane.showMessageDialog(this, "Sorry, you've run out of guesses. The word was: " + targetWord);
        }
        // Reset the guessed letters and start a new game
        guessedLetters.clear();
        startGame();
    }

    private boolean isWordGuessed() {
        // Check if all letters in the target word have been guessed
        for (char c : targetWord.toCharArray()) {
            if (!guessedLetters.contains(c)) {
                return false;
            }
        }
        return true;
    }

    // Custom button class to handle background color change when disabled
    private class CustomButton extends JButton {
        private boolean guessed;

        public CustomButton(String text) {
            super(text);
            this.guessed = false;
        }

        public void setGuessed(boolean guessed) {
            this.guessed = guessed;
            updateBackground();
        }

        private void updateBackground() {
            if (guessed) {
                setBackground(Color.LIGHT_GRAY);
            } else {
                setBackground(Color.WHITE);
            }
        }

        @Override
        public void setEnabled(boolean enabled) {
            super.setEnabled(enabled);
            updateBackground();
        }
    }

    private void updateGuessButtonColor() {
        if (isGameOver()) {
            guessButton.setBackground(Color.RED); // Change the background color of the guess button when the game is over
        } else {
            guessButton.setBackground(Color.WHITE); // Reset the background color of the guess button
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
}
