// Event listener triggered when the DOM content is fully loaded
document.addEventListener('DOMContentLoaded', function () {
    // Populate the hour and minute select elements
    populateTimeSelects('startHour');
    populateTimeSelects('endHour');
    populateTimeSelects('startMinute');
    populateTimeSelects('endMinute');

    // Get all frequency buttons
    var frequencyButtons = document.querySelectorAll('.frequency-button');

    // Add click event listeners to handle button selection
    frequencyButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            handleFrequencySelection(button);
        });
    });

    // Get the Save Changes button by ID
    var saveChangesButton = document.getElementById('saveChangesBtn');

    // Add click event listener for the Save Changes button
    saveChangesButton.addEventListener('click', function () {
        handleSaveChanges();
    });

    // Get the Back button by ID
    var backButton = document.getElementById('backButton');

    // Add click event listener for the Back button
    backButton.addEventListener('click', function () {
        handleBack();
    });

    // Get the Add Time Period button by ID
    var addTimePeriodButton = document.getElementById('addTimePeriodBtn');

    // Add click event listener for the Add Time Period button
    addTimePeriodButton.addEventListener('click', function () {
        addTimePeriodRow();
    });

    // Initially add one time period row
    addTimePeriodRow();
});

// Function to add a new time period row
function addTimePeriodRow() {
    // Get the container for time period rows
    var timePeriodsContainer = document.getElementById('timePeriodsContainer');

    // Create a new time period row
    var newRow = document.createElement('div');
    newRow.classList.add('time-period');

    // Add HTML content for the time period row
    newRow.innerHTML = `
        <div class="time-label">Start Time:</div>
        <select class="time-select startHour"></select>
        <span class="time-separator">:</span>
        <select class="time-select startMinute"></select>

        <div class="time-label">End Time:</div>
        <select class="time-select endHour"></select>
        <span class="time-separator">:</span>
        <select class="time-select endMinute"></select>

        <button class="remove-time-period-btn">Remove</button>
    `;

    // Populate the new time period row with select options
    populateTimeSelects('startHour', newRow);
    populateTimeSelects('endHour', newRow);
    populateTimeSelects('startMinute', newRow);
    populateTimeSelects('endMinute', newRow);

    // Add change event listeners for end time selects to validate against start time
    var startHourSelect = newRow.querySelector('.startHour');
    var startMinuteSelect = newRow.querySelector('.startMinute');
    var endHourSelect = newRow.querySelector('.endHour');
    var endMinuteSelect = newRow.querySelector('.endMinute');

    startHourSelect.addEventListener('change', function () {
        // Validate start time against end time
        validateTimeSelection(startHourSelect, startMinuteSelect, endHourSelect, endMinuteSelect);
    });

    startMinuteSelect.addEventListener('change', function () {
        // Validate start time against end time
        validateTimeSelection(startHourSelect, startMinuteSelect, endHourSelect, endMinuteSelect);
    });

    endHourSelect.addEventListener('change', function () {
        // Validate end time against start time
        validateTimeSelection(startHourSelect, startMinuteSelect, endHourSelect, endMinuteSelect);
    });

    endMinuteSelect.addEventListener('change', function () {
        // Validate end time against start time
        validateTimeSelection(startHourSelect, startMinuteSelect, endHourSelect, endMinuteSelect);
    });

    // Append the new time period row to the container
    timePeriodsContainer.appendChild(newRow);

    // Add click event listener for the remove button
    var removeButton = newRow.querySelector('.remove-time-period-btn');
    removeButton.addEventListener('click', function () {
        timePeriodsContainer.removeChild(newRow);
    });
}

// Function to populate the hour and minute select elements
function populateTimeSelects(selectId, parentElement) {
    var selectElement = parentElement ? parentElement.querySelector('.' + selectId) : document.getElementById(selectId);
    var isHourSelect = selectId.includes('Hour');
    var range = isHourSelect ? Array.from({ length: 24 }, (_, i) => i) : Array.from({ length: 60 }, (_, i) => i);

    // Clear any existing options
    selectElement.innerHTML = '';

    // Iterate through the range to create options for the select element
    range.forEach(function (value) {
        var option = document.createElement('option');
        option.value = value;
        option.text = value < 10 ? '0' + value : value.toString(); // Format single-digit values with a leading zero
        selectElement.add(option);
    });
}

// Function to handle Save Changes button click
function handleSaveChanges() {
    // Display a popup indicating that Save Changes button is clicked
    showPopup("Save Changes Button Clicked");
}

// Function to handle Back button click
function handleBack() {
    // Display a popup indicating that Back button is clicked
    window.location.href = 'settingsPage.php';
}

// Function to show a popup with a custom message
function showPopup(message) {
    alert(message);
}

// Function to validate time selection (start time not greater than end time)
function validateTimeSelection(startHourSelect, startMinuteSelect, endHourSelect, endMinuteSelect) {
    var startHour = parseInt(startHourSelect.value);
    var endHour = parseInt(endHourSelect.value);
    var startMinute = parseInt(startMinuteSelect.value);
    var endMinute = parseInt(endMinuteSelect.value);

    // If start hour is greater than end hour, or if start hour is equal to end hour but start minute is greater than end minute
    if (startHour > endHour || (startHour === endHour && startMinute > endMinute)) {
        // Reset end time to match start time
        endHourSelect.value = startHour;
        endMinuteSelect.value = startMinute;

        showPopup("End time cannot be earlier than start time.");
    }
}
