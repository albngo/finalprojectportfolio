<?php
// Include the database connection file
include('database.php');

// Check if edit event form is submitted
if (isset($_POST['edit_event'])) {
    // Get values from the form
    $taskId = $_POST['task_id'];
    $title = $_POST['title'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $hour = $_POST['hour'];
    $minutes = $_POST['minutes'];
    $venue = $_POST['venue'];
    $notes = $_POST['notes'];

    // Perform the update query
    $updateQuery = "UPDATE tasks 
                    SET title = ?, day = ?, month = ?, year = ?, hour = ?, minutes = ?, venue = ?, notes = ?
                    WHERE idtasks = ?";
    $updateStmt = $mysqli->prepare($updateQuery);

    // Bind parameters to the prepared statement
    $updateStmt->bind_param("siiiiissi", $title, $day, $month, $year, $hour, $minutes, $venue, $notes, $taskId);

    // Execute the statement
    if ($updateStmt->execute()) {
        // Task updated successfully, redirect back to task page
        header("Location: taskPage.php");
        exit();
    } else {
        // Error occurred during update
        echo "Error updating task: " . $mysqli->error;
    }

    // Close the statement
    $updateStmt->close();
}

// Close the database connection
$mysqli->close();
?>
