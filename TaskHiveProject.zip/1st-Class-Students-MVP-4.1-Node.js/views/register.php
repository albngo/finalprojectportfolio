<?php
include('database.php'); // Include the database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];

    // Insert user data into the database
    $sql = "INSERT INTO `user` (username, password, email, sleepTime) VALUES ('$username', '$password', '$email', 0)";
    if ($mysqli->query($sql) === TRUE) {
        echo "Registration successful";
        // Redirect user to the login page
        header("Location: loginPage.php");
        exit(); // Stop executing the script
    } else {
        echo "Error: " . $sql . "<br>" . $mysqli->error;
    }
}
?>
