<?php
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: loginPage.php");
    exit();
}

// Include the database connection file
include('database.php');

// Check if task ID is provided via GET parameter
if (isset($_GET['task_id'])) {
    // Get the task ID from the URL
    $taskId = $_GET['task_id'];

    // Fetch task details from the database
    $query = "SELECT * FROM tasks WHERE idtasks = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("i", $taskId);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if task exists
    if ($result->num_rows > 0) {
        $task = $result->fetch_assoc();

        // Populate form fields with task details
        $taskId = $task['idtasks'];
        $title = $task['title'];
        $day = $task['day'];
        $month = $task['month'];
        $year = $task['year'];
        $hour = $task['hour'];
        $minutes = $task['minutes'];
        $venue = $task['venue'];
        $notes = $task['notes'];
    } else {
        // Task not found
        $error_message = "Task not found!";
    }

    $stmt->close();
} else {
    // Task ID not provided
    $error_message = "Task ID not provided!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/TaskPagestyle.css">
    <title>Edit Event - Task Manager</title>
</head>
<body>
    <!-- Main container for the entire task manager -->
    <div class="task-manager-container">
        <!-- Header section containing live date and small calendar UI -->
        <div class="header">
            <div class="live-date"> <!-- Live date display -->
                <!-- Actual live date content will be dynamically updated here -->
                <!-- JS Code needed here for real dynamic date display, this is just a placeholder. thx Joseph ;P -->
                <h2><span id="current-date">Saturday 20-01-2024</span></h2>
            </div>
            <div class="small-calendar"> <!-- Small calendar UI -->
                <!-- Current month calendar content will be dynamically updated here -->
            </div>
        </div>

        <!-- Main content section for task manager features -->
        <div class="task-manager-content">
            <!-- Edit Event form section -->
            <div class="add-event-section">
                <?php if (isset($error_message)): ?>
                    <p><?php echo $error_message; ?></p>
                <?php else: ?>
                    <form method="post" action="updateTask.php">
                        <!-- Edit Event form content goes here -->
                        <!-- Include input fields for various details (day, month, year, hour, minutes, title, venue, notes, etc.) -->
                        <input type="hidden" name="task_id" value="<?php echo $taskId; ?>">
                        <label for="event-title">Title:</label>
                        <input type="text" id="event-title" name="title" value="<?php echo $title; ?>" required>

                        <label for="event-day">Day:</label>
                        <input type="number" id="event-day" name="day" value="<?php echo $day; ?>" required>

                        <label for="event-month">Month:</label>
                        <input type="number" id="event-month" name="month" value="<?php echo $month; ?>" required>

                        <label for="event-year">Year:</label>
                        <input type="number" id="event-year" name="year" value="<?php echo $year; ?>" required>

                        <label for="event-hour">Hour:</label>
                        <input type="number" id="event-hour" name="hour" value="<?php echo $hour; ?>" required>

                        <label for="event-minutes">Minutes:</label>
                        <input type="number" id="event-minutes" name="minutes" value="<?php echo $minutes; ?>" required>

                        <label for="event-venue">Venue:</label>
                        <input type="text" id="event-venue" name="venue" value="<?php echo $venue; ?>">

                        <label for="event-notes">Notes:</label>
                        <textarea id="event-notes" name="notes"><?php echo $notes; ?></textarea>

                        <!-- Add a submit button to submit the form -->
                        <button type="submit" name="edit_event">Save Event</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <!-- End of task-manager-content -->
    </div>
    <!-- End of task-manager-container -->
</body>
</html>
