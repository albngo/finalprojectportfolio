<?php
// Include the database connection file
include('database.php');

// Check if the add event form is submitted
if (isset($_POST['add_event'])) {
    // Get values from the form
    $title = $_POST['title'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $hour = $_POST['hour'];
    $minutes = $_POST['minutes'];
    $venue = $_POST['venue'];
    $notes = $_POST['notes'];

    // Perform the insertion query
    $insertQuery = "INSERT INTO tasks (day, month, year, hour, minutes, title, venue, notes)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $insertStmt = $mysqli->prepare($insertQuery);

    // Bind parameters to the prepared statement
    $insertStmt->bind_param("iiiiiiss", $day, $month, $year, $hour, $minutes, $title, $venue, $notes);

    // Execute the statement
    if ($insertStmt->execute()) {
        // Task added successfully, you can redirect or show a success message
        header("Location: taskPage.php");
        exit();
    } else {
        // Error occurred during insertion
        echo "Error adding task: " . $mysqli->error;
    }

    // Close the statement
    $insertStmt->close();
}

// Close the database connection
$mysqli->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="taskPageStyle.css">
    <title>Add Event - Task Manager</title>
</head>
<body>
    <!-- Main container for the entire task manager -->
    <div class="task-manager-container">
        <!-- Header section containing live date and small calendar UI -->
        <div class="header">
            <div class="live-date"> <!-- Live date display -->
                <!-- Actual live date content will be dynamically updated here -->
                <!-- JS Code needed here for real dynamic date display, this is just a placeholder. thx Joseph ;P -->
                <h2><span id="current-date">Saturday 20-01-2024</span></h2>
            </div>
            <div class="small-calendar"> <!-- Small calendar UI -->
                <!-- Current month calendar content will be dynamically updated here -->
            </div>
        </div>

        <!-- Main content section for task manager features -->
        <div class="task-manager-content">
            <!-- Task buttons for various actions -->
            <div class="task-buttons">
                <a href="taskPage.php"><button>Home</button></a>
                <button>Create New List</button>
                <a href="addEvent.php"><button>Add Event</button></a>
                <a href="editTask.php"><button>Edit Event</button></a>
                <a href="deleteTask.php"><button>Delete Event</button></a>
                <button>Auto Schedule Event</button>
                <button>Add Reminder</button>
                <button>Import List</button>
            </div>

            <!-- Add Event form section -->
            <div class="add-event-section">
                <form method="post" action="">
                    <!-- Add Event form content goes here -->
                    <!-- Include input fields for various details (day, month, year, hour, minutes, title, venue, notes, etc.) -->

                    <!-- Example input fields -->
                    <label for="event-title">Title:</label>
                    <input type="text" id="event-title" name="title" required>

                    <label for="event-day">Day:</label>
                    <select id="event-day" name="day" required>
                        <?php
                        // Generate options for days (1 to 31)
                        for ($i = 1; $i <= 31; $i++) {
                            echo "<option value='$i'>$i</option>";
                        }
                        ?>
                    </select>

                    <label for="event-month">Month:</label>
                    <select id="event-month" name="month" required>
                        <?php
                        // Generate options for months (January to December)
                        $months = array(
                            1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June',
                            7 => 'July', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                        );
                        foreach ($months as $key => $value) {
                            echo "<option value='$key'>$value</option>";
                        }
                        ?>
                    </select>

                    <label for="event-year">Year:</label>
                    <select id="event-year" name="year" required>
                        <?php
                        // Generate options for years (current year to 10 years ahead)
                        $currentYear = date("Y");
                        $endYear = $currentYear + 10;
                        for ($year = $currentYear; $year <= $endYear; $year++) {
                            echo "<option value='$year'>$year</option>";
                        }
                        ?>
                    </select>

                    <label for="event-time">Hour:</label>
                    <input type="number" id="event-hour" name="hour" required>

                    <label for="event-minutes">Minutes:</label>
                    <input type="number" id="event-minutes" name="minutes" required>

                    <label for="event-venue">Venue:</label>
                    <input type="text" id="event-venue" name="venue">

                    <label for="event-notes">Notes:</label>
                    <textarea id="event-notes" name="notes"></textarea>

                    <!-- Add a submit button to submit the form -->
                    <button type="submit" name="add_event">Add Event</button>
                </form>
            </div>
        </div>
        <!-- End of task-manager-content -->
    </div>
    <!-- End of task-manager-container -->
</body>
</html>
