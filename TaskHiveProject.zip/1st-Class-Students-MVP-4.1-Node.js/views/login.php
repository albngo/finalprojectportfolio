<?php
session_start();
include('database.php'); // Include the database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['login_username'];
    $password = $_POST['login_password'];

    // Check if user exists in the database
    $sql = "SELECT iduser FROM `user` WHERE username='$username' AND password='$password'";
    $result = $mysqli->query($sql);

    if ($result->num_rows == 1) {
        // Login successful
        $row = $result->fetch_assoc();
        $_SESSION['user_id'] = $row['iduser']; // Store the user's ID in the session
        header("Location: homePage.php"); // Redirect to homePage.php
        exit(); // Stop executing the script
    } else {
        // Login failed
        $_SESSION['login_error'] = "Username or password is incorrect";
        header("Location: loginPage.php"); // Redirect back to login page
        exit(); // Stop executing the script
    }
}
?>
