<?php
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: loginPage.php");
    exit();
}

// Include the database connection file
include('database.php');

// Check if the delete task form is submitted
if (isset($_POST['delete_task'])) {
    // Get the task ID from the form
    $taskId = $_POST['task_id'];

    // Perform the deletion query
    $deleteQuery = "DELETE FROM tasks WHERE idtasks = ?";
    $deleteStmt = $mysqli->prepare($deleteQuery);
    $deleteStmt->bind_param("i", $taskId);

    if ($deleteStmt->execute()) {
        // Task deleted successfully, you can redirect or show a success message
        header("Location: taskPage.php");
        exit();
    } else {
        // Error occurred during deletion
        echo "Error deleting task: " . $mysqli->error;
    }

    // Close the statement
    $deleteStmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/TaskPagestyle.css">
    <title>Task Manager</title>
</head>
<body>
    <!-- Main container for the entire task manager -->
    <div class="task-manager-container">
        <!-- Header section containing live date and small calendar UI -->
        <div class="header">
            <div class="live-date"> <!-- Live date display -->
                <!-- Actual live date content will be dynamically updated here -->
                <!-- JS Code needed here for real dynamic date display, this is just a placeholder. thx Joseph ;P -->
                <h2><span id="current-date">Saturday 20-01-2024</span></h2>
            </div>
            <div class="small-calendar"> <!-- Small calendar UI -->
                <!-- Current month calendar content will be dynamically updated here -->
            </div>
        </div>

        <!-- Main content section for task manager features -->
        <div class="task-manager-content">
            <!-- Task buttons for various actions -->
            <div class="task-buttons">
                <a href="taskPage.php"><button>Home</button></a>
                <button>Create New List</button>
                <a href="addEvent.php"><button>Add Event</button></a>
                <a href="editTask.php"><button>Edit Event</button></a>
                <button>Delete Event</button>
                <button>Auto Schedule Event</button>
                <button>Add Reminder</button>
                <button>Import List</button>
            </div>

           <!-- Task display section -->
            <div class="task-display-section">
                <!-- Task display buttons for different views -->
                <div class="task-display-buttons">
                    <button id="in-progress-btn" class="selected">Tasks in Progress</button>
                    <button id="upcoming-btn">Upcoming Tasks</button>
                    <button id="completed-btn">Completed Tasks</button>
                    <button id="all-events-btn">All Events</button>
                </div>

                <!-- Header displaying the currently selected task display button -->
                <div class="selected-header">
                    <h3><span id="selected-display-title">Tasks in Progress</span></h3>
                </div>

                <div class="task-displays">
                    <?php
                    // Fetch tasks from the database
                    $query = "SELECT * FROM tasks";
                    $result = $mysqli->query($query);

                    // Check for errors
                    if (!$result) {
                        die("Error: " . $mysqli->error);
                    }

                    // Loop through the retrieved tasks and display them in task cards
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="task-card in-progress-tasks">';
                        echo '<div class="task-box">';
                        echo '<span class="task-title">' . $row['title'] . '</span>';

                        // Format the date without leading zeros and in the desired format
                        $formattedDate = date("j, F Y", mktime(0, 0, 0, $row['month'], $row['day'], $row['year']));
                        echo '<span class="task-date">' . $formattedDate . '</span>';

                        echo '<span class="task-time">' . $row['hour'] . ':' . $row['minutes'] . '</span>';
                        echo '<span class="task-notes">' . $row['notes'] . '</span>'; // Display notes
                        echo '</div>';

                        // Add a delete button
                        echo '<form method="post" action="">';
                        echo '<input type="hidden" name="task_id" value="' . $row['idtasks'] . '">';
                        echo '<button type="submit" name="delete_task">Delete</button>';
                        echo '</form>';
                        
                        echo '</div>';
                    }

                    // Close the result set
                    $result->close();
                    ?>
                    
                    <!-- Create similar task cards for other display options -->
                </div>
                <!-- End of task-displays -->
            </div>
            <!-- End of task-display-section -->
        </div>
        <!-- End of task-manager-content -->
    </div>
    <!-- End of task-manager-container -->
</body>
</html>
