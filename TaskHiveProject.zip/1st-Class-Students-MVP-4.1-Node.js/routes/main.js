const bcrypt = require('bcrypt');
module.exports = function(app, tempData) {

    // public access routes, no sessions required
    app.get('/', (req, res) => {
        res.render('landing.html'); 
    });
    // login successful redirects to homepage
    app.get('/homepage', (req, res) => {
        res.render('homePage.html', {username: req.session.username}); 
    });
    app.get('/resource', (req, res) => {
        res.render('resource.html'); 
    });
    app.get('/about', (req, res) => {
        res.render('about.html'); 
    });
    // routes that enable login and sign up
    app.get('/login', (req,res) => {
        res.render('loginPage.html', { error: ' '});
    });
    app.get('/signup', (req, res) => {
        res.render('loginPage.html');
    });

    // -------- route for creating new user --------
    app.post('/register', (req, res) => {
        const { username, email, password } = req.body;

        // Hash the password
        bcrypt.hash(password, 10, (err, hashedPassword) => {
          if (err) {
            console.error('Error hashing password: ' + err);
            res.status(500).send('Error hashing password');
            return;
          }
      
          // Insert a new row into the user table
          const query = "INSERT INTO user (username, email, password) VALUES (?, ?, ?)";
          db.query(query, [username, email, hashedPassword], (err, result) => {
            if (err) {
              console.error('Error inserting user: ' + err);
              res.status(500).send('Error inserting user');
              return;
            }
            console.log('User inserted successfully');
            res.redirect('/login');
          });
        });
    });

    // -------- route for validating user login --------
    app.post('/login-process', (req, res) => {
        const { login_username, login_password } = req.body;

        // Retrieve hashed password from the database
        const query = "SELECT iduser, username, password FROM user WHERE username = ?";
        db.query(query, [login_username], (err, results) => {
            if (err) {
                console.error('Error retrieving user: ' + err);
                res.status(500).send('Error retrieving user');
                return;
            }
            
            if (results.length === 0) {
                // Render the login page again with an error message
                res.render('loginPage.html', { error: 'User not found'});
                return;
            }
            
            const user = results[0];
            
            // Compare hashed password with the provided password
            bcrypt.compare(login_password, user.password, (err, result) => {
                if (err) {
                    console.error('Error comparing passwords: ' + err);
                    res.render('loginPage.html', { error: 'Incorrect Password'});
                    return;
                }
            });
            session = req.session;
            session.username = login_username;
            session.save((err) => {
                if (err) {
                    res.redirect('./');
                }
                res.redirect('/homepage'); 
            });
        });

    });

    // routes that will require session to access
    app.get('/settings', (req, res) => {
        res.render('settingsPage.html'); 
    });
    app.get('/autoscheduler', (req, res) => {
        res.render('autoschedule.html'); 
    });

    // Render taskPage.ejs
    app.get('/taskPage', (req, res) => {
        res.render('taskPage.html');
    });

    // Render updateTask.ejs
    app.get('/updateTask', (req, res) => {
        res.render('updateTask.hmtl');
    });
};
